
from flask import Flask, render_template, redirect, request, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config
from models import db, Member, Order
import qrcode
import os

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

mail = Mail(app)

@login_manager.user_loader
def load_user(user_id):
    return Member.query.get(int(user_id))

@app.before_first_request
def create_tables():
    db.create_all()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/products')
def products():
    return render_template('products.html')

@app.route('/cart')
@login_required
def cart():
    return render_template('cart.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/events')
def events():
    return render_template('events.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        existing = Member.query.filter_by(email=email).first()
        if existing:
            flash('此 Email 已註冊')
            return redirect(url_for('register'))

        member_id = 'VP' + str(100000 + Member.query.count() + 1)
        hashed_pw = generate_password_hash(request.form['password'], method='sha256')
        member = Member(
            member_id=member_id,
            name=request.form['name'],
            email=email,
            phone=request.form['phone'],
            address=request.form['address'],
            birthday=request.form['birthday'],
            password=hashed_pw,
            points=0,
            level='綠翠會員'
        )
        db.session.add(member)
        db.session.commit()

        # 產生 QR Code
        img = qrcode.make(member_id)
        img.save(f'static/images/qrcode.png')

        # 寄送 Email
        try:
            msg = Message('歡迎加入翠峰飲品會員！',
                          sender=app.config['MAIL_USERNAME'],
                          recipients=[email])
            msg.body = f"您好 {member.name}，歡迎加入翠峰甘露！您的會員編號為 {member_id}"
            mail.send(msg)
        except Exception as e:
            print("寄信失敗：", e)

        flash('註冊成功，請登入')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        user = Member.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for('member'))
        else:
            flash('帳號或密碼錯誤')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/member')
@login_required
def member():
    orders = Order.query.filter_by(member_id=current_user.member_id).all()
    return render_template('member.html', member=current_user, orders=orders)

if __name__ == '__main__':
    app.run(debug=True)


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'verdantpeak' and password == 'verdantpeak':
            session['admin'] = True
            return redirect('/admin/dashboard')
        else:
            flash('管理員帳密錯誤')
            return redirect('/admin/login')
    return render_template('admin/admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect('/admin/login')
    return render_template('admin/admin_dashboard.html')


@app.route('/member/edit', methods=['GET', 'POST'])
@login_required
def edit_member():
    if request.method == 'POST':
        current_user.name = request.form['name']
        current_user.phone = request.form['phone']
        current_user.address = request.form['address']
        current_user.birthday = request.form['birthday']
        if request.form['password']:
            current_user.password = generate_password_hash(request.form['password'], method='sha256')
        db.session.commit()
        flash('資料已更新')
        return redirect(url_for('member'))
    return render_template('member_edit.html', member=current_user)


@app.route('/redeem', methods=['GET', 'POST'])
@login_required
def redeem():
    from models import RedeemItem, RedeemHistory
    if request.method == 'POST':
        item_id = request.form['item_id']
        item = RedeemItem.query.get(item_id)
        if item and current_user.points >= item.cost:
            current_user.points -= item.cost
            history = RedeemHistory(
                member_id=current_user.member_id,
                item_name=item.name,
                points_used=item.cost
            )
            db.session.add(history)
            db.session.commit()
            flash(f"成功兌換：{item.name}")
            return redirect(url_for('member'))
        else:
            flash("點數不足或商品不存在")
            return redirect(url_for('redeem'))

    items = RedeemItem.query.all()
    return render_template('redeem.html', member=current_user, items=items)


@app.route('/event/signup', methods=['GET', 'POST'])
def event_signup():
    from models import EventSignup
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        event_name = request.form['event_name']

        signup = EventSignup(name=name, email=email, phone=phone, event_name=event_name)
        db.session.add(signup)
        db.session.commit()

        # 發送報名確認 Email
        try:
            msg = Message('您已成功報名活動',
                          sender=app.config['MAIL_USERNAME'],
                          recipients=[email])
            msg.body = f"您好 {name}，您已成功報名活動：{event_name}！我們將與您聯繫後續資訊。"
            mail.send(msg)
        except Exception as e:
            print("報名信寄送失敗：", e)

        flash('報名成功！已寄出確認信')
        return redirect(url_for('index'))

    return render_template('event_signup.html')


@app.route('/admin/events')
def admin_events():
    if not session.get('admin'):
        return redirect('/admin/login')
    from models import EventSignup
    signups = EventSignup.query.order_by(EventSignup.created_at.desc()).all()
    return render_template('admin/admin_events.html', signups=signups)
