
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class Member(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.String(20), unique=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(120), unique=True)
    phone = db.Column(db.String(20))
    address = db.Column(db.String(200))
    birthday = db.Column(db.String(20))
    password = db.Column(db.String(200))
    points = db.Column(db.Integer, default=0)
    level = db.Column(db.String(20), default='綠翠會員')

    def get_id(self):
        return str(self.id)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.String(20), db.ForeignKey('member.member_id'))
    product = db.Column(db.String(100))
    quantity = db.Column(db.Integer)
    status = db.Column(db.String(50), default='製作中')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    price = db.Column(db.Integer)
    image_url = db.Column(db.String(200))
    stock = db.Column(db.Integer, default=0)


class RedeemItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    image = db.Column(db.String(300))
    cost = db.Column(db.Integer)

class RedeemHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.String(20))
    item_name = db.Column(db.String(100))
    points_used = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class EventSignup(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20))
    event_name = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
