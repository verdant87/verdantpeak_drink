
# Verdant Peak 官方網站 - Flask 後端系統

## 功能
- 會員註冊 / 登入 / 登出
- 訂單紀錄查詢
- 點數計算與等級升級
- QR Code 生成
- 寄送歡迎註冊 Email
- Render 部署

## Render 部署步驟
1. 到 https://render.com 建立帳號，綁定 GitHub。
2. 建立新 Web Service，選擇你的 GitHub 專案。
3. 設定環境變數：
   - `SECRET_KEY`：任何字串
   - `MAIL_USERNAME`：你的 Gmail 帳號
   - `MAIL_PASSWORD`：你的 Gmail 應用程式密碼
4. 選擇 Python + 建立完即可自動部署。

## 啟動方式（本地端）
```bash
pip install -r requirements.txt
python app.py
```
